package com.tren;

public class Vagon extends ElementoTren {

    public Vagon(double carga) {
        setTipo("Vagon");
        setLongitud(18.28);
        setPeso(25400 + carga);
    }
}
