package com.tren;

public class Tren {
    private double capacidadCarga;
    private ElementoTren[] elementos;
    private double longitud;
    private int numElementos;
    private double peso;
    private int tamActual;

    public Tren() {
        capacidadCarga = 0;
        elementos = new ElementoTren[100];
        longitud = 0;
        numElementos = 0;
        peso = 0;
        tamActual = 0;

        agregarLocomotora(new Locomotora());
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void getInfo() {
        System.out.println("--- Dimensiones ---");
        System.out.println("Número de elementos: " + numElementos);
        System.out.println("Peso: " + peso);
        System.out.println("Longitud " + longitud);
        System.out.println("Capacidad de carga: " + capacidadCarga);

        for (int i = 0; i < numElementos; i++) {
            System.out.print(elementos[i].toString());
        }
    }

    public double getLongitud() {
        return longitud;
    }

    public int getNumElementos() {
        return numElementos;
    }

    public double getPeso() {
        return peso;
    }

    public int getTamActual() {
        return tamActual;
    }

    public void agregarLocomotora(Locomotora locomotora) {
        if (numElementos < 100) {
            elementos[numElementos++] = locomotora;
            ajustaDimensiones(locomotora);
        }
    }

    public void agregarVagones(Vagon vagon) {
        if (peso + vagon.getPeso() > capacidadCarga && numElementos < 100) {
            while (peso + vagon.getPeso() > capacidadCarga) {
                agregarLocomotora(new Locomotora());
            }
            elementos[numElementos++] = vagon;
            ajustaDimensiones(vagon);
        } else if (numElementos < 100) {
            elementos[numElementos++] = vagon;
            ajustaDimensiones(vagon);
        }
    }

    public void ajustaDimensiones(ElementoTren elemento) {
        if (elemento.getTipo().equals("Locomotora")) {
            capacidadCarga += 200000;
        }
        longitud += elemento.getLongitud();
        peso += elemento.getPeso();
    }

    @Override
    public String toString() {
        return "Tren";
    }
}
