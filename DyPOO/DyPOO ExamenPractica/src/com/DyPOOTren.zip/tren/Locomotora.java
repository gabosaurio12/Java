package com.tren;

public class Locomotora extends ElementoTren {
    private double capacidadCarga;

    public Locomotora() {
        setTipo("Locomotora");
        setLongitud(20.17);
        setPeso(92600);
        capacidadCarga = 200000;
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }
}
