package org.biblioteca;

import java.util.Map;
import java.util.Scanner;

public class Gestion {

    // INICIO Funciones de Miembros

    public void registrarMiembro(Map<String, Miembro> miembros) {
        Scanner scn = new Scanner(System.in);
        Miembro miembroRegisrar = new Miembro(miembros.size());
        String id = miembroRegisrar.getId();
        miembros.put(id, miembroRegisrar);
        System.out.println("ID: " + miembroRegisrar.getId());
        scn.nextLine();
    }

    public void cancelarMembresia(Map<String, Miembro> miembros, String id) {

        if (miembros.get(id) != null) {
            miembros.remove(id);
            System.out.println("Membresía cancelada");
        } else {
            System.out.println("No se encontró el usuario");
        }

    }

    public void mostrarPrestamos(Map<String, Miembro> miembros, String id) {

        Scanner scn = new Scanner(System.in);
        Miembro miembroBuscado = miembros.get(id);
        for (int i = 0; i < miembroBuscado.getPrestamos(); i++) {
            miembroBuscado.imprimirPrestamo(i);
            System.out.println("Multa: " + miembroBuscado.getMulta());
        }

        scn.nextLine();
    }

    public void mostrarMiembros(Map<String, Miembro> miembros) {

        for (Map.Entry<String, Miembro> me: miembros.entrySet()) {
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue().getNombre());
            System.out.println();
        }
    }

    // FIN Funciones de Miembros

    // INICIO Funcionse para actualizar información

    public void actualizarInformacionLibro(String isbn, Map<String, Libro> libros) {

        Libro libroBuscado = libros.get(isbn);

        if (libroBuscado != null) {
            Scanner scn = new Scanner(System.in);

            System.out.println("Qué editarás: ");
            System.out.println("1. Título");
            System.out.println("2. Autor");
            System.out.println("3. Género");
            System.out.println("4. Categoría");
            System.out.println("5. Año de publicación");
            System.out.println("6. Copias Disponibles");
            int opc = scn.nextInt();
            scn.nextLine();
            String nuevoDato;
            int nuevoEntero;
            switch (opc) {
                case 1:
                    nuevoDato = scn.nextLine();
                    libroBuscado.setTitulo(nuevoDato);
                    break;
                case 2:
                    nuevoDato = scn.nextLine();
                    libroBuscado.setAutor(nuevoDato);
                    break;
                case 3:
                    nuevoDato = scn.nextLine();
                    libroBuscado.setGenero(nuevoDato);
                    break;
                case 4:
                    nuevoDato = scn.nextLine();
                    libroBuscado.setCategoria(nuevoDato);
                    break;
                case 5:
                    nuevoEntero = scn.nextInt();
                    libroBuscado.setAnoDePublicacion(nuevoEntero);
                    break;
                case 6:
                    nuevoEntero = scn.nextInt();
                    libroBuscado.setCopiasDisponibles(nuevoEntero);
                    break;
            }
        } else {
            System.out.println("No se encontró el libro");
        }
    }

    // FIN Funciones para actualizar información

    public void actualizarInfoMiembro(String id, Map<String, Miembro> miembros) {

        Miembro miembroBuscado = miembros.get(id);
        if (miembroBuscado != null) {
            Scanner scn = new Scanner(System.in);

            System.out.println("Qué editarás: ");
            System.out.println("1. Nombre");
            System.out.println("2. Dirección");
            System.out.println("3. Tipo de Membresía");
            int opc = scn.nextInt();
            scn.nextLine();
            String nuevoDato;
            switch (opc) {
                case 1:
                    nuevoDato = scn.nextLine();
                    miembroBuscado.setNombre(nuevoDato);
                    break;
                case 2:
                    nuevoDato = scn.nextLine();
                    miembroBuscado.setDireccion(nuevoDato);
                    break;
                case 3:
                    nuevoDato = scn.nextLine();
                    miembroBuscado.setTipoMembresia(nuevoDato);
                    break;
            }
        } else {
            System.out.println("Usuario no encontrado");
        }
    }

    // INICIO Funciones de Libros

    public void prestarLibro(Map<String, Libro> libros, Map<String, Miembro> miembros, String id) {

        Miembro usrBuscado = miembros.get(id);
        if (usrBuscado != null) {
            Scanner scn = new Scanner(System.in);

            System.out.print("ISBN: ");
            String isbnAux = scn.nextLine();
            Libro libBuscado = libros.get(isbnAux);
            if (libBuscado != null && libBuscado.getCopiasDisponibles() > 0) {
                usrBuscado.agregarPrestamo(libBuscado);
                libBuscado.setCopiasDisponibles(libBuscado.getCopiasDisponibles() - 1);
                libBuscado.configurarFechas();
            } else {
                System.out.println("No disponible");
            }
        } else {
            System.out.println("Usuario no encontrado");
        }
    }

    public void devolverLibro(Map<String, Libro> libros, Map<String, Miembro> miembros, String id) {

        Miembro usrBuscado = miembros.get(id);
        if (usrBuscado != null) {
            Scanner scn = new Scanner(System.in);

            System.out.print("ISBN: ");
            String isbnAux = scn.nextLine();
            Libro libBuscado = libros.get(isbnAux);
            if (libBuscado != null) {
                libBuscado.setCopiasDisponibles(libBuscado.getCopiasDisponibles() + 1);
                usrBuscado.devolverPrestamo(libBuscado);
            }
        }
    }

    public void agregarLibro(Map<String, Libro> libros) {

        Libro libroNuevo = new Libro();
        libros.put(libroNuevo.getISBN(), libroNuevo);
    }

    public void eliminarLibro(Map<String, Libro> libros) {

        Scanner scn = new Scanner(System.in);
        System.out.print("ISBN: ");
        String isbnAux = scn.nextLine();
        libros.remove(isbnAux);
    }

    // FIN Funciones de Libros

    // Funciones para mostrar el inventario

    public void mostrarLibAutor(Map<String, Libro> libros, String autor) {

        for (Map.Entry<String, Libro> i: libros.entrySet()) {
            if (i.getValue().getAutor().equals(autor)) {
                System.out.print(i.getKey() + ": ");
                System.out.print(i.getValue().getTitulo());
            }
        }
    }

    public void mostrarLibGenero(Map<String, Libro> libros, String genero) {

        for (Map.Entry<String, Libro> i: libros.entrySet()) {
            if (i.getValue().getGenero().equals(genero)) {
                System.out.print(i.getKey() + ": ");
                System.out.print(i.getValue().getTitulo());
            }
        }
    }

    public void mostrarLibPublicacion(Map<String, Libro> libros, int publi) {

        for (Map.Entry<String, Libro> i: libros.entrySet()) {
            if (i.getValue().getAnoDePublicacion() == publi) {
                System.out.print(i.getKey() + ": ");
                System.out.print(i.getValue().getTitulo());
            }
        }
    }

    public void mostrarInvLibros(Map<String, Libro> libros) {

        System.out.println("Como los desea ordenar");
        System.out.println("1. Autor");
        System.out.println("2. Género");
        System.out.println("3. Año de publicación");
        Scanner scn = new Scanner(System.in);
        int opc = scn.nextInt();
        scn.nextLine();
        switch (opc) {
            case 1:
                System.out.print("Autor: ");
                String autor = scn.nextLine();
                mostrarLibAutor(libros, autor);
                scn.nextLine();
                break;
            case 2:
                System.out.print("Genero: ");
                String genero = scn.nextLine();
                mostrarLibGenero(libros, genero);
                scn.nextLine();
                break;
            case 3:
                System.out.print("Autor: ");
                int publi = scn.nextInt();
                mostrarLibPublicacion(libros, publi);
                scn.nextLine();
                break;
            default:
                System.out.println("Mostrando por orden de alta");
                for (Map.Entry<String, Libro> i: libros.entrySet()) {
                    System.out.print(i.getKey() + ": ");
                    System.out.println(i.getValue().getTitulo());
                    System.out.println();
                }
                scn.nextLine();
                break;
        }
    }
}
